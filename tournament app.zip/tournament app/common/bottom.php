<?php
$page_name = basename($_SERVER['PHP_SELF']);
$nav_items = [
    'index.php' => ['icon' => 'fa-house', 'label' => 'Home'],
    'my_tournaments.php' => ['icon' => 'fa-trophy', 'label' => 'My Games'],
    'leaderboard.php' => ['icon' => 'fa-star', 'label' => 'Ranking'],
    'wallet.php' => ['icon' => 'fa-wallet', 'label' => 'Wallet'],
    'profile.php' => ['icon' => 'fa-user', 'label' => 'Profile'],
];
?>
        </main>
    </div>
    <nav class="fixed bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 max-w-lg mx-auto">
        <div class="flex justify-around">
            <?php foreach($nav_items as $file => $item): ?>
                <?php $is_active = ($page_name == $file); ?>
                <a href="<?php echo $file; ?>" class="flex-1 text-center py-3 text-sm transition-colors duration-300 <?php echo $is_active ? 'text-cyan-400 bg-gray-900' : 'text-gray-400 hover:text-white'; ?>">
                    <i class="fas <?php echo $item['icon']; ?> text-xl mb-1"></i>
                    <span class="block text-xs"><?php echo $item['label']; ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    </nav>
    <script> document.addEventListener('contextmenu', e => e.preventDefault()); </script>
</body>
</html>
