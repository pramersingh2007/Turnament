<?php
require_once 'config.php';
function is_user_logged_in() { return isset($_SESSION["user_id"]); }
function require_login() { if (!is_user_logged_in()) { header("location: login.php"); exit; } }
$page_name = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        body { -webkit-user-select: none; -ms-user-select: none; user-select: none; background-color: #111827; color: #f3f4f6; font-family: 'Inter', sans-serif; padding-bottom: 80px; }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="font-sans">
    <div class="container mx-auto max-w-lg min-h-screen">
        <main class="p-4">
