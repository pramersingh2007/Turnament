<?php
// index.php - User Dashboard
require_once 'common/header.php';
require_login(); // This function ensures the user is logged in

$user_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

// Handle joining a tournament
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['join_tournament'])) {
    $tournament_id = $_POST['tournament_id'];
    $entry_fee = $_POST['entry_fee'];
    
    $result = $mysqli->query("SELECT wallet_balance FROM users WHERE id = $user_id");
    $user = $result->fetch_assoc();
    
    if ($user['wallet_balance'] >= $entry_fee) {
        $mysqli->begin_transaction();
        try {
            $mysqli->query("UPDATE users SET wallet_balance = wallet_balance - $entry_fee WHERE id = $user_id");
            
            $stmt = $mysqli->prepare("INSERT INTO registrations (user_id, tournament_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $user_id, $tournament_id);
            $stmt->execute();
            
            $mysqli->commit();
            $message = 'Successfully joined the tournament!';
            $message_type = 'success';
        } catch (mysqli_sql_exception $exception) {
            $mysqli->rollback();
            if($mysqli->errno === 1062){
                 $message = 'You are already registered for this tournament.';
            } else {
                 $message = 'An error occurred. Please try again.';
            }
            $message_type = 'error';
        }
    } else {
        $message = 'Insufficient wallet balance to join.';
        $message_type = 'error';
    }
}

$sql = "SELECT t.*, 
        (SELECT COUNT(*) FROM registrations r WHERE r.tournament_id = t.id) as registered_players
        FROM tournaments t
        WHERE t.status = 'upcoming'
        ORDER BY t.start_time ASC";
$tournaments = $mysqli->query($sql);
?>
<header class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold text-white">Lobby</h1>
    <div class="text-right">
        <p class="text-gray-400 text-sm">Welcome back,</p>
        <h2 class="text-lg font-semibold text-cyan-400"><?php echo htmlspecialchars($_SESSION['username']); ?></h2>
    </div>
</header>

<?php if ($message): ?>
    <div class="p-4 mb-4 text-sm rounded-lg <?php echo $message_type == 'success' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'; ?>">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<div class="space-y-4">
    <?php if ($tournaments->num_rows > 0): ?>
        <?php while($row = $tournaments->fetch_assoc()): ?>
            <?php
            $reg_check_sql = "SELECT id FROM registrations WHERE user_id = ? AND tournament_id = ?";
            $stmt_check = $mysqli->prepare($reg_check_sql);
            $stmt_check->bind_param("ii", $user_id, $row['id']);
            $stmt_check->execute();
            $stmt_check->store_result();
            $is_registered = $stmt_check->num_rows > 0;
            $stmt_check->close();
            $spots_left = $row['max_players'] - $row['registered_players'];
            $is_full = $spots_left <= 0;
            ?>
            <div class="bg-gray-800 rounded-lg overflow-hidden shadow-lg">
                <img src="<?php echo htmlspecialchars($row['image_url'] ?: 'https://via.placeholder.com/400x200.png/1f2937/9ca3af?text=Game+Art'); ?>" alt="Game Art" class="w-full h-32 object-cover">
                <div class="p-4">
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="text-xl font-bold text-white"><?php echo htmlspecialchars($row['name']); ?></h3>
                            <p class="text-sm text-gray-400"><?php echo htmlspecialchars($row['game_name']); ?></p>
                        </div>
                        <div class="text-right">
                             <p class="text-lg font-bold text-cyan-400"><?php echo htmlspecialchars($row['prize_pool']); ?></p>
                             <p class="text-xs text-gray-500">Prize Pool</p>
                        </div>
                    </div>
                    <div class="flex justify-between items-center mt-4 text-sm">
                        <div class="text-center">
                            <p class="font-semibold text-white">₹<?php echo htmlspecialchars($row['entry_fee']); ?></p>
                            <p class="text-xs text-gray-500">Entry</p>
                        </div>
                        <div class="text-center">
                            <p class="font-semibold text-white"><?php echo date('d M, h:i A', strtotime($row['start_time'])); ?></p>
                            <p class="text-xs text-gray-500">Starts</p>
                        </div>
                         <div class="text-center">
                            <p class="font-semibold text-white"><?php echo $row['registered_players'] . '/' . $row['max_players']; ?></p>
                            <p class="text-xs text-gray-500">Players</p>
                        </div>
                    </div>
                    <div class="mt-4">
                        <form action="index.php" method="POST">
                            <input type="hidden" name="tournament_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="entry_fee" value="<?php echo $row['entry_fee']; ?>">
                            <?php if ($is_registered): ?>
                                <button type="button" class="w-full bg-green-600 text-white font-bold py-2 rounded-lg cursor-not-allowed" disabled>
                                    <i class="fas fa-check-circle"></i> Joined
                                </button>
                            <?php elseif ($is_full): ?>
                                <button type="button" class="w-full bg-red-600 text-white font-bold py-2 rounded-lg cursor-not-allowed" disabled>
                                    <i class="fas fa-times-circle"></i> Full
                                </button>
                            <?php else: ?>
                                <button type="submit" name="join_tournament" class="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 rounded-lg transition">
                                    Join Now
                                </button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="bg-gray-800 text-center p-8 rounded-lg">
            <i class="fas fa-ghost text-4xl text-gray-600 mb-4"></i>
            <p class="text-gray-400">No upcoming tournaments right now. Check back later!</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'common/bottom.php'; ?>
