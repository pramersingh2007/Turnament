<?php
require_once 'common/header.php';
require_admin_login();
?>

<h1 class="text-3xl font-bold text-white mb-6">Settings</h1>

<div class="bg-gray-800 text-center p-8 rounded-lg">
    <i class="fas fa-tools text-4xl text-gray-600 mb-4"></i>
    <p class="text-gray-400">This is a placeholder for future app settings.</p>
</div>

<?php require_once 'common/bottom.php'; ?>
