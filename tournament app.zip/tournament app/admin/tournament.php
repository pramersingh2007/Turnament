<?php
require_once 'common/header.php';
require_admin_login();

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$message_type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : '';
unset($_SESSION['message'], $_SESSION['message_type']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_tournament'])) {
    $id_to_delete = $_POST['id'];
    $stmt = $mysqli->prepare("DELETE FROM tournaments WHERE id = ?");
    $stmt->bind_param("i", $id_to_delete);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Tournament deleted successfully.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting tournament.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
    header("Location: tournament.php");
    exit;
}

$result = $mysqli->query("SELECT * FROM tournaments ORDER BY start_time DESC");
?>

<div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-bold text-white">Manage Tournaments</h1>
    <a href="manage_tournament.php" class="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-lg transition">
        <i class="fas fa-plus mr-2"></i>Create New
    </a>
</div>

<?php if ($message): ?>
    <div class="p-4 mb-4 text-sm rounded-lg <?php echo $message_type == 'success' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'; ?>">
        <?php echo htmlspecialchars($message); ?>
    </div>
<?php endif; ?>

<div class="bg-gray-800 rounded-lg shadow-lg overflow-x-auto">
    <table class="w-full text-sm text-left text-gray-300">
        <thead class="text-xs text-gray-400 uppercase bg-gray-700">
            <tr>
                <th class="px-6 py-3">Name</th>
                <th class="px-6 py-3">Game</th>
                <th class="px-6 py-3">Entry Fee</th>
                <th class="px-6 py-3">Status</th>
                <th class="px-6 py-3">Starts At</th>
                <th class="px-6 py-3">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr class="border-b border-gray-700 hover:bg-gray-700/50">
                    <th class="px-6 py-4 font-medium text-white whitespace-nowrap"><?php echo htmlspecialchars($row['name']); ?></th>
                    <td class="px-6 py-4"><?php echo htmlspecialchars($row['game_name']); ?></td>
                    <td class="px-6 py-4">₹<?php echo htmlspecialchars($row['entry_fee']); ?></td>
                    <td class="px-6 py-4"><?php echo ucfirst(htmlspecialchars($row['status'])); ?></td>
                    <td class="px-6 py-4"><?php echo date('d M Y, H:i', strtotime($row['start_time'])); ?></td>
                    <td class="px-6 py-4 flex items-center space-x-3">
                        <a href="manage_tournament.php?id=<?php echo $row['id']; ?>" class="font-medium text-cyan-400 hover:underline">Edit</a>
                        <form action="tournament.php" method="POST" onsubmit="return confirm('Are you sure?');">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit" name="delete_tournament" class="font-medium text-red-400 hover:underline">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                 <tr><td colspan="6" class="text-center py-8 text-gray-400">No tournaments found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'common/bottom.php'; ?>
