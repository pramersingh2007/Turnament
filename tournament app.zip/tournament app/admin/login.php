<?php
require_once __DIR__ . '/../common/config.php';

if (isset($_SESSION["admin_id"])) {
    header("location: index.php");
    exit;
}
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    if (empty($username) || empty($password)) {
        $error = "Please enter username and password.";
    } else {
        $sql = "SELECT id, username, password_hash FROM admins WHERE username = ?";
        if ($stmt = $mysqli->prepare($sql)) {
            $stmt->bind_param("s", $username);
            if ($stmt->execute()) {
                $stmt->store_result();
                if ($stmt->num_rows == 1) {
                    $stmt->bind_result($id, $username, $hashed_password);
                    if ($stmt->fetch()) {
                        if (password_verify($password, $hashed_password)) {
                            $_SESSION["admin_id"] = $id;
                            $_SESSION["admin_username"] = $username;
                            header("location: index.php");
                            exit;
                        } else { $error = "Invalid password."; }
                    }
                } else { $error = "No admin account found."; }
            } else { $error = "Oops! Something went wrong."; }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style> body { background-color: #111827; } </style>
</head>
<body class="flex items-center justify-center min-h-screen">
    <div class="bg-gray-800 p-8 rounded-lg shadow-lg w-full max-w-sm text-white">
        <h1 class="text-2xl font-bold text-center text-cyan-400 mb-6">Admin Login</h1>
        <?php if ($error): ?>
            <p class="bg-red-500/20 text-red-300 p-3 rounded-lg mb-4 text-sm"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="login.php" method="POST">
            <div class="mb-4">
                <label class="block mb-2">Username</label>
                <input type="text" name="username" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
            </div>
            <div class="mb-6">
                <label class="block mb-2">Password</label>
                <input type="password" name="password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
            </div>
            <button type="submit" class="w-full bg-cyan-600 hover:bg-cyan-700 font-bold py-3 rounded-lg transition">Login</button>
        </form>
    </div>
</body>
</html>
