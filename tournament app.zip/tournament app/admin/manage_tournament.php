<?php
require_once 'common/header.php';
require_admin_login();

$page_title = 'Create Tournament';
$tournament = [
    'id' => '', 'name' => '', 'game_name' => '', 'entry_fee' => '', 'prize_pool' => '',
    'max_players' => '', 'start_time' => '', 'status' => 'upcoming', 'image_url' => ''
];
$errors = [];
$is_edit = false;

if (isset($_GET['id'])) {
    $is_edit = true;
    $id = $_GET['id'];
    $page_title = 'Edit Tournament';
    $stmt = $mysqli->prepare("SELECT * FROM tournaments WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $tournament = $result->fetch_assoc();
    } else {
        $_SESSION['message'] = "Tournament not found.";
        $_SESSION['message_type'] = "error";
        header("Location: tournament.php");
        exit;
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tournament['id'] = $_POST['id'];
    $tournament['name'] = trim($_POST['name']);
    $tournament['game_name'] = trim($_POST['game_name']);
    $tournament['entry_fee'] = trim($_POST['entry_fee']);
    $tournament['prize_pool'] = trim($_POST['prize_pool']);
    $tournament['max_players'] = trim($_POST['max_players']);
    $tournament['start_time'] = trim($_POST['start_time']);
    $tournament['status'] = trim($_POST['status']);
    $tournament['image_url'] = trim($_POST['image_url']);
    
    if (empty($tournament['name'])) $errors[] = "Tournament name is required.";
    if (!is_numeric($tournament['entry_fee']) || $tournament['entry_fee'] < 0) $errors[] = "Entry fee must be a valid number.";
    
    if (empty($errors)) {
        if ($is_edit) {
            $sql = "UPDATE tournaments SET name=?, game_name=?, entry_fee=?, prize_pool=?, max_players=?, start_time=?, status=?, image_url=? WHERE id=?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssdssissi", $tournament['name'], $tournament['game_name'], $tournament['entry_fee'], $tournament['prize_pool'], $tournament['max_players'], $tournament['start_time'], $tournament['status'], $tournament['image_url'], $tournament['id']);
        } else {
            $sql = "INSERT INTO tournaments (name, game_name, entry_fee, prize_pool, max_players, start_time, status, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssdssiss", $tournament['name'], $tournament['game_name'], $tournament['entry_fee'], $tournament['prize_pool'], $tournament['max_players'], $tournament['start_time'], $tournament['status'], $tournament['image_url']);
        }
        
        if ($stmt->execute()) {
            $_SESSION['message'] = "Tournament saved successfully.";
            $_SESSION['message_type'] = "success";
            header("Location: tournament.php");
            exit;
        } else {
            $errors[] = "Database error: " . $stmt->error;
        }
        $stmt->close();
    }
}

?>
<h1 class="text-3xl font-bold text-white mb-6"><?php echo $page_title; ?></h1>
<?php if (!empty($errors)): ?>
    <div class="bg-red-500/20 border border-red-500 text-red-300 px-4 py-3 rounded-lg mb-4">
        <ul><li>- <?php echo implode('</li><li>- ', $errors); ?></li></ul>
    </div>
<?php endif; ?>

<div class="bg-gray-800 p-8 rounded-lg shadow-lg">
    <form action="manage_tournament.php<?php if($is_edit) echo '?id='.$tournament['id']; ?>" method="POST">
        <input type="hidden" name="id" value="<?php echo $tournament['id']; ?>">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-gray-300 mb-2">Tournament Name</label>
                <input type="text" name="name" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="<?php echo htmlspecialchars($tournament['name']); ?>" required>
            </div>
             <div>
                <label class="block text-gray-300 mb-2">Game Name</label>
                <input type="text" name="game_name" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="<?php echo htmlspecialchars($tournament['game_name']); ?>" required>
            </div>
             <div>
                <label class="block text-gray-300 mb-2">Entry Fee (₹)</label>
                <input type="number" step="0.01" name="entry_fee" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="<?php echo htmlspecialchars($tournament['entry_fee']); ?>" required>
            </div>
             <div>
                <label class="block text-gray-300 mb-2">Prize Pool</label>
                <input type="text" name="prize_pool" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="<?php echo htmlspecialchars($tournament['prize_pool']); ?>" placeholder="e.g., ₹10,000" required>
            </div>
             <div>
                <label class="block text-gray-300 mb-2">Max Players</label>
                <input type="number" name="max_players" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="<?php echo htmlspecialchars($tournament['max_players']); ?>" required>
            </div>
            <div>
                <label class="block text-gray-300 mb-2">Start Time</label>
                <input type="datetime-local" name="start_time" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="<?php echo date('Y-m-d\TH:i', strtotime($tournament['start_time'])); ?>" required>
            </div>
             <div>
                <label class="block text-gray-300 mb-2">Status</label>
                <select name="status" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500">
                    <option value="upcoming" <?php if($tournament['status'] == 'upcoming') echo 'selected'; ?>>Upcoming</option>
                    <option value="ongoing" <?php if($tournament['status'] == 'ongoing') echo 'selected'; ?>>Ongoing</option>
                    <option value="completed" <?php if($tournament['status'] == 'completed') echo 'selected'; ?>>Completed</option>
                </select>
            </div>
             <div>
                <label class="block text-gray-300 mb-2">Image URL (Optional)</label>
                <input type="url" name="image_url" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="<?php echo htmlspecialchars($tournament['image_url']); ?>">
            </div>
        </div>
        <div class="mt-6 flex justify-end space-x-4">
            <a href="tournament.php" class="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg transition">Cancel</a>
            <button type="submit" class="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-6 rounded-lg transition">Save Tournament</button>
        </div>
    </form>
</div>

<?php require_once 'common/bottom.php'; ?>
