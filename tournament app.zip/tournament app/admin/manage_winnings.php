<?php
require_once 'common/header.php';
require_admin_login();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: user.php");
    exit;
}
$user_id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount_to_add = trim($_POST['amount']);
    
    if (!is_numeric($amount_to_add) || $amount_to_add <= 0) {
        $error = "Please enter a valid positive amount.";
    } else {
        $mysqli->begin_transaction();
        try {
            $sql = "UPDATE users SET total_winnings = total_winnings + ?, wallet_balance = wallet_balance + ? WHERE id = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ddi", $amount_to_add, $amount_to_add, $user_id);
            $stmt->execute();
            
            $mysqli->commit();
            $_SESSION['message'] = "Winnings added successfully.";
            $_SESSION['message_type'] = "success";
            header("Location: user.php");
            exit;
        } catch (mysqli_sql_exception $exception) {
            $mysqli->rollback();
            $error = "Database error: Failed to add winnings.";
        }
    }
}

$stmt = $mysqli->prepare("SELECT username, total_winnings, wallet_balance FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    header("Location: user.php");
    exit;
}
$user = $result->fetch_assoc();
$stmt->close();
?>

<h1 class="text-3xl font-bold text-white mb-2">Manage Winnings</h1>
<p class="text-lg text-cyan-400 font-semibold mb-6"><?php echo htmlspecialchars($user['username']); ?></p>

<?php if (isset($error)): ?>
    <div class="bg-red-500/20 border border-red-500 text-red-300 px-4 py-3 rounded-lg mb-4">
        <p><?php echo $error; ?></p>
    </div>
<?php endif; ?>

<div class="bg-gray-800 p-8 rounded-lg shadow-lg max-w-md">
    <div class="mb-6">
        <p class="text-gray-400">Current Total Winnings:</p>
        <p class="text-2xl font-bold">₹<?php echo number_format($user['total_winnings'], 2); ?></p>
    </div>
     <div class="mb-6">
        <p class="text-gray-400">Current Wallet Balance:</p>
        <p class="text-2xl font-bold">₹<?php echo number_format($user['wallet_balance'], 2); ?></p>
    </div>
    
    <form action="manage_winnings.php?id=<?php echo $user_id; ?>" method="POST">
        <div class="mb-4">
            <label for="amount" class="block text-gray-300 mb-2">Amount to Add (₹)</label>
            <input type="number" step="0.01" id="amount" name="amount" class="w-full bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="e.g., 500" required>
            <p class="text-xs text-gray-500 mt-2">This amount will be added to both Total Winnings and Wallet Balance.</p>
        </div>
        <div class="mt-6 flex justify-end space-x-4">
            <a href="user.php" class="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg transition">Cancel</a>
            <button type="submit" class="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-6 rounded-lg transition">Add Winnings</button>
        </div>
    </form>
</div>

<?php require_once 'common/bottom.php'; ?>
