<?php
require_once 'common/header.php';
require_admin_login();

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$message_type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : '';
unset($_SESSION['message'], $_SESSION['message_type']);

$result = $mysqli->query("SELECT id, username, email, wallet_balance, total_winnings, created_at FROM users ORDER BY created_at DESC");
?>

<h1 class="text-3xl font-bold text-white mb-6">Manage Users</h1>

<?php if ($message): ?>
    <div class="p-4 mb-4 text-sm rounded-lg <?php echo $message_type == 'success' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'; ?>">
        <?php echo htmlspecialchars($message); ?>
    </div>
<?php endif; ?>

<div class="bg-gray-800 rounded-lg shadow-lg overflow-x-auto">
    <table class="w-full text-sm text-left text-gray-300">
        <thead class="text-xs text-gray-400 uppercase bg-gray-700">
            <tr>
                <th class="px-6 py-3">Username</th>
                <th class="px-6 py-3">Email</th>
                <th class="px-6 py-3">Wallet</th>
                <th class="px-6 py-3">Winnings</th>
                <th class="px-6 py-3">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr class="border-b border-gray-700 hover:bg-gray-700/50">
                    <th class="px-6 py-4 font-medium text-white whitespace-nowrap"><?php echo htmlspecialchars($row['username']); ?></th>
                    <td class="px-6 py-4"><?php echo htmlspecialchars($row['email']); ?></td>
                    <td class="px-6 py-4">₹<?php echo htmlspecialchars($row['wallet_balance']); ?></td>
                    <td class="px-6 py-4">₹<?php echo htmlspecialchars($row['total_winnings']); ?></td>
                    <td class="px-6 py-4">
                        <a href="manage_winnings.php?id=<?php echo $row['id']; ?>" class="font-medium text-cyan-400 hover:underline">Manage</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                 <tr><td colspan="5" class="text-center py-8 text-gray-400">No users found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'common/bottom.php'; ?>
