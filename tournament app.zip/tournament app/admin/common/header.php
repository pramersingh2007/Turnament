<?php
require_once __DIR__ . '/../../common/config.php';
function is_admin_logged_in() { return isset($_SESSION["admin_id"]); }
function require_admin_login() { if (!is_admin_logged_in()) { header("location: login.php"); exit; } }
$page_name = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style> body { background-color: #111827; color: #f3f4f6; } </style>
</head>
<body class="font-sans">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-gray-300 p-4 flex flex-col">
            <h1 class="text-2xl font-bold text-cyan-400 mb-8"><?php echo APP_NAME; ?> Admin</h1>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center px-4 py-2 rounded-lg transition hover:bg-gray-700 <?php if($page_name == 'index.php') echo 'bg-cyan-600/50 text-white'; ?>"><i class="fas fa-chart-pie fa-fw mr-3"></i>Dashboard</a>
                <a href="tournament.php" class="flex items-center px-4 py-2 rounded-lg transition hover:bg-gray-700 <?php if(in_array($page_name, ['tournament.php', 'manage_tournament.php'])) echo 'bg-cyan-600/50 text-white'; ?>"><i class="fas fa-trophy fa-fw mr-3"></i>Tournaments</a>
                <a href="user.php" class="flex items-center px-4 py-2 rounded-lg transition hover:bg-gray-700 <?php if(in_array($page_name, ['user.php', 'manage_winnings.php'])) echo 'bg-cyan-600/50 text-white'; ?>"><i class="fas fa-users fa-fw mr-3"></i>Users</a>
                 <a href="setting.php" class="flex items-center px-4 py-2 rounded-lg transition hover:bg-gray-700 <?php if($page_name == 'setting.php') echo 'bg-cyan-600/50 text-white'; ?>"><i class="fas fa-cog fa-fw mr-3"></i>Settings</a>
            </nav>
            <div class="mt-auto">
                 <a href="logout.php" class="flex items-center px-4 py-2 rounded-lg transition hover:bg-red-800/50 text-red-400"><i class="fas fa-sign-out-alt fa-fw mr-3"></i>Logout</a>
            </div>
        </aside>
        <main class="flex-1 p-8">
