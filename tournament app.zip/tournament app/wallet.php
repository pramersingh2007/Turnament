<?php
require_once 'common/header.php';
require_login();

$user_id = $_SESSION['user_id'];
$sql = "SELECT wallet_balance FROM users WHERE id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>

<h1 class="text-2xl font-bold text-white mb-6">My Wallet</h1>

<div class="bg-gradient-to-br from-cyan-500 to-blue-600 p-6 rounded-xl shadow-lg text-white mb-8">
    <p class="text-sm opacity-80">Current Balance</p>
    <p class="text-4xl font-bold mt-1">₹<?php echo number_format($user['wallet_balance'], 2); ?></p>
</div>

<div class="flex space-x-4 mb-8">
    <button class="flex-1 bg-cyan-600 hover:bg-cyan-700 font-semibold py-3 rounded-lg transition-transform transform active:scale-95">
        <i class="fas fa-plus-circle mr-2"></i> Add Funds
    </button>
    <button class="flex-1 bg-gray-700 hover:bg-gray-600 font-semibold py-3 rounded-lg transition-transform transform active:scale-95">
        <i class="fas fa-arrow-down-circle mr-2"></i> Withdraw
    </button>
</div>

<h2 class="text-xl font-bold text-white mb-4">Transaction History</h2>
<div class="bg-gray-800 text-center p-8 rounded-lg">
    <i class="fas fa-receipt text-4xl text-gray-600 mb-4"></i>
    <p class="text-gray-400">No recent transactions found.</p>
</div>

<?php require_once 'common/bottom.php'; ?>
