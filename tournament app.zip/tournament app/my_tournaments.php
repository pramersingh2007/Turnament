<?php
require_once 'common/header.php';
require_login();

$user_id = $_SESSION['user_id'];
$sql = "SELECT t.*, r.registered_at FROM tournaments t
        JOIN registrations r ON t.id = r.tournament_id
        WHERE r.user_id = ?
        ORDER BY t.start_time DESC";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<h1 class="text-2xl font-bold text-white mb-6">My Tournaments</h1>

<div class="space-y-4">
    <?php if ($result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
            <?php
                $status_color = 'bg-yellow-500/20 text-yellow-300';
                if ($row['status'] == 'ongoing') {
                    $status_color = 'bg-blue-500/20 text-blue-300';
                } elseif ($row['status'] == 'completed') {
                    $status_color = 'bg-gray-500/20 text-gray-300';
                }
            ?>
            <div class="bg-gray-800 rounded-lg p-4 shadow-lg flex items-center space-x-4">
                <img src="<?php echo htmlspecialchars($row['image_url'] ?: 'https://via.placeholder.com/100x100.png/1f2937/9ca3af?text=Game'); ?>" alt="Game Art" class="w-20 h-20 rounded-md object-cover">
                <div class="flex-1">
                    <div class="flex justify-between items-start">
                         <div>
                            <h3 class="text-lg font-bold text-white"><?php echo htmlspecialchars($row['name']); ?></h3>
                            <p class="text-sm text-gray-400"><?php echo htmlspecialchars($row['game_name']); ?></p>
                         </div>
                        <span class="text-xs font-semibold px-2 py-1 rounded-full <?php echo $status_color; ?>">
                            <?php echo ucfirst($row['status']); ?>
                        </span>
                    </div>
                    <div class="flex justify-between items-end mt-2 text-xs text-gray-400">
                        <div>
                            <p>Starts: <?php echo date('d M, h:i A', strtotime($row['start_time'])); ?></p>
                            <p>Prize: <span class="font-semibold text-cyan-400"><?php echo htmlspecialchars($row['prize_pool']); ?></span></p>
                        </div>
                        <div class="text-right">
                             <p>Entry: <span class="font-semibold text-white">₹<?php echo htmlspecialchars($row['entry_fee']); ?></span></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="bg-gray-800 text-center p-8 rounded-lg">
            <i class="fas fa-trophy text-4xl text-gray-600 mb-4"></i>
            <p class="text-gray-400">You haven't joined any tournaments yet.</p>
            <a href="index.php" class="mt-4 inline-block bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-lg transition">Find a Game</a>
        </div>
    <?php endif; ?>
</div>

<?php
$stmt->close();
require_once 'common/bottom.php';
?>
