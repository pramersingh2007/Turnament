<?php
require_once 'common/header.php';
require_login();

$user_id = $_SESSION['user_id'];

// Fetch user's referral code
$stmt_code = $mysqli->prepare("SELECT referral_code FROM users WHERE id = ?");
$stmt_code->bind_param("i", $user_id);
$stmt_code->execute();
$user = $stmt_code->get_result()->fetch_assoc();
$referral_code = $user['referral_code'];
$stmt_code->close();

// Fetch users referred by the current user
$stmt_referred = $mysqli->prepare("SELECT username, created_at FROM users WHERE referred_by_id = ? ORDER BY created_at DESC");
$stmt_referred->bind_param("i", $user_id);
$stmt_referred->execute();
$referred_users = $stmt_referred->get_result();
$stmt_referred->close();
?>

<h1 class="text-2xl font-bold text-white mb-6">🤝 Refer & Earn</h1>
<p class="text-gray-400 mb-6">Share your code with friends. When they sign up, you'll earn <span class="font-bold text-cyan-400">₹1</span> in your wallet for each successful referral!</p>

<div class="bg-gray-800 p-6 rounded-lg text-center mb-8">
    <p class="text-gray-400 text-sm">Your Unique Referral Code</p>
    <div class="my-4 p-3 border-2 border-dashed border-gray-600 rounded-lg">
        <p id="referralCode" class="text-3xl font-bold tracking-widest text-cyan-400"><?php echo htmlspecialchars($referral_code); ?></p>
    </div>
    <button onclick="copyCode()" class="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 rounded-lg transition">
        <i class="fas fa-copy mr-2"></i><span id="copyText">Copy Code</span>
    </button>
</div>

<h2 class="text-xl font-bold text-white mb-4">Your Referrals (<?php echo $referred_users->num_rows; ?>)</h2>
<div class="space-y-3">
    <?php if ($referred_users->num_rows > 0): ?>
        <?php while($row = $referred_users->fetch_assoc()): ?>
            <div class="flex items-center justify-between bg-gray-800 p-4 rounded-lg">
                <p class="font-semibold text-white"><?php echo htmlspecialchars($row['username']); ?></p>
                <p class="text-sm text-gray-400">Joined: <?php echo date('d M, Y', strtotime($row['created_at'])); ?></p>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p class="text-gray-500 text-center py-4">You haven't referred anyone yet.</p>
    <?php endif; ?>
</div>

<script>
function copyCode() {
    const code = document.getElementById('referralCode').innerText;
    navigator.clipboard.writeText(code).then(() => {
        const copyText = document.getElementById('copyText');
        copyText.innerText = 'Copied!';
        setTimeout(() => { copyText.innerText = 'Copy Code'; }, 2000);
    });
}
</script>

<?php require_once 'common/bottom.php'; ?>
