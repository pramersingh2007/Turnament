<?php
// install.php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$errors = [];
$success = '';

function write_config_file($host, $user, $pass, $db) {
    $config_content = "<?php
// Adept Play - Configuration File
if (session_status() == PHP_SESSION_NONE) { session_start(); }
ini_set('display_errors', 1);
error_reporting(E_ALL);

define('DB_SERVER', '{$host}');
define('DB_USERNAME', '{$user}');
define('DB_PASSWORD', '{$pass}');
define('DB_NAME', '{$db}');

\$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
if (\$mysqli === false || \$mysqli->connect_error) {
    die(\"ERROR: Could not connect to database. \" . \$mysqli->connect_error);
}
define('APP_NAME', 'Adept Play');
?>";
    if (file_put_contents('common/config.php', $config_content)) {
        return true;
    }
    return false;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && $step == 1) {
    $db_host = trim($_POST['db_host']);
    $db_user = trim($_POST['db_user']);
    $db_pass = trim($_POST['db_pass']);
    $db_name = trim($_POST['db_name']);

    if (empty($db_host)) $errors[] = "Database Host is required.";
    if (empty($db_user)) $errors[] = "Database Username is required.";
    if (empty($db_name)) $errors[] = "Database Name is required.";

    if (empty($errors)) {
        try {
            $conn = new mysqli($db_host, $db_user, $db_pass);
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }
            
            $sql = "CREATE DATABASE IF NOT EXISTS `$db_name`";
            if (!$conn->query($sql)) {
                 throw new Exception("Error creating database: " . $conn->error);
            }
            $conn->select_db($db_name);

            $sql_queries = [
                "CREATE TABLE IF NOT EXISTS `admins` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `username` varchar(50) NOT NULL UNIQUE,
                  `password_hash` varchar(255) NOT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                "CREATE TABLE IF NOT EXISTS `users` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `username` varchar(50) NOT NULL UNIQUE,
                  `email` varchar(100) NOT NULL UNIQUE,
                  `password_hash` varchar(255) NOT NULL,
                  `wallet_balance` decimal(10,2) NOT NULL DEFAULT 1000.00,
                  `total_winnings` decimal(10,2) NOT NULL DEFAULT 0.00,
                  `referral_code` varchar(10) NOT NULL UNIQUE,
                  `referred_by_id` int(11) NULL DEFAULT NULL,
                  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

                "CREATE TABLE IF NOT EXISTS `tournaments` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `name` varchar(100) NOT NULL,
                  `game_name` varchar(50) NOT NULL,
                  `entry_fee` decimal(10,2) NOT NULL,
                  `prize_pool` varchar(50) NOT NULL,
                  `max_players` int(11) NOT NULL,
                  `start_time` datetime NOT NULL,
                  `status` enum('upcoming','ongoing','completed') NOT NULL DEFAULT 'upcoming',
                  `image_url` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
                
                "CREATE TABLE IF NOT EXISTS `registrations` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `user_id` int(11) NOT NULL,
                  `tournament_id` int(11) NOT NULL,
                  `registered_at` timestamp NOT NULL DEFAULT current_timestamp(),
                  PRIMARY KEY (`id`),
                  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
                  FOREIGN KEY (`tournament_id`) REFERENCES `tournaments`(`id`) ON DELETE CASCADE,
                  UNIQUE KEY `user_tournament` (`user_id`,`tournament_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
            ];
            
            foreach ($sql_queries as $query) {
                if (!$conn->query($query)) {
                    throw new Exception("Error creating table: " . $conn->error);
                }
            }

            $admin_user = 'admin';
            $admin_pass = password_hash('password123', PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO `admins` (username, password_hash) VALUES (?, ?) ON DUPLICATE KEY UPDATE username=username;");
            $stmt->bind_param("ss", $admin_user, $admin_pass);
            if (!$stmt->execute()) {
                throw new Exception("Error creating default admin: " . $stmt->error);
            }
            $stmt->close();
            
            if (!write_config_file($db_host, $db_user, $db_pass, $db_name)) {
                throw new Exception("Error: Could not write to common/config.php. Please check file permissions.");
            }
            
            $conn->close();
            $success = "Installation successful!";
            $step = 2;

        } catch (Exception $e) {
            $errors[] = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Adept Play - Installation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style> body { -webkit-user-select: none; -ms-user-select: none; user-select: none; } </style>
</head>
<body class="bg-gray-900 text-white font-sans flex items-center justify-center min-h-screen">
    <div class="bg-gray-800 p-8 rounded-lg shadow-lg w-full max-w-md">
        <h1 class="text-3xl font-bold text-center text-cyan-400 mb-6">Adept Play Installer</h1>
        <?php if (!empty($errors)): ?>
            <div class="bg-red-500/20 border border-red-500 text-red-300 px-4 py-3 rounded-lg mb-4">
                <strong class="font-bold">Error!</strong>
                <ul><li>- <?php echo implode('</li><li>- ', $errors); ?></li></ul>
            </div>
        <?php endif; ?>
        <?php if ($step == 1): ?>
            <p class="text-gray-400 mb-6 text-center">Enter your database details to begin.</p>
            <form action="install.php?step=1" method="POST">
                <div class="mb-4">
                    <label for="db_host" class="block text-gray-300 mb-2">Database Host</label>
                    <input type="text" id="db_host" name="db_host" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="localhost" required>
                </div>
                <div class="mb-4">
                    <label for="db_user" class="block text-gray-300 mb-2">Database Username</label>
                    <input type="text" id="db_user" name="db_user" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="root" required>
                </div>
                <div class="mb-4">
                    <label for="db_pass" class="block text-gray-300 mb-2">Database Password</label>
                    <input type="password" id="db_pass" name="db_pass" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500">
                </div>
                <div class="mb-6">
                    <label for="db_name" class="block text-gray-300 mb-2">Database Name</label>
                    <input type="text" id="db_name" name="db_name" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" value="adept_play_db" required>
                </div>
                <button type="submit" class="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 rounded-lg transition duration-300">Install Now</button>
            </form>
        <?php elseif ($step == 2): ?>
             <div class="text-center">
                <div class="bg-green-500/20 border border-green-500 text-green-300 px-4 py-3 rounded-lg mb-4"><p><?php echo $success; ?></p></div>
                <p class="text-gray-300 mb-4">Default Admin: <strong class="text-white">admin</strong> / <strong class="text-white">password123</strong></p>
                <div class="mt-6 bg-yellow-500/20 border border-yellow-500 text-yellow-300 p-4 rounded-lg">
                    <h3 class="font-bold text-lg mb-2"><i class="fas fa-exclamation-triangle"></i> IMPORTANT!</h3>
                    <p>For security, please delete the <strong class="text-white">install.php</strong> file from your server.</p>
                </div>
                <a href="login.php" class="inline-block mt-6 bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-6 rounded-lg transition">Go to User Login</a>
             </div>
        <?php endif; ?>
    </div>
    <script> document.addEventListener('contextmenu', e => e.preventDefault()); </script>
</body>
</html>
