<?php
require_once 'common/header.php';
require_login();

$user_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $message = "Please fill all password fields.";
        $message_type = 'error';
    } elseif ($new_password != $confirm_password) {
        $message = "New passwords do not match.";
        $message_type = 'error';
    } else {
        $sql = "SELECT password_hash FROM users WHERE id = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($password_hash);
        $stmt->fetch();
        $stmt->close();

        if (password_verify($current_password, $password_hash)) {
            $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $update_sql = "UPDATE users SET password_hash = ? WHERE id = ?";
            $update_stmt = $mysqli->prepare($update_sql);
            $update_stmt->bind_param("si", $new_password_hash, $user_id);
            if ($update_stmt->execute()) {
                $message = "Password updated successfully.";
                $message_type = 'success';
            } else {
                $message = "Failed to update password.";
                $message_type = 'error';
            }
            $update_stmt->close();
        } else {
            $message = "Incorrect current password.";
            $message_type = 'error';
        }
    }
}

$sql = "SELECT username, email, created_at FROM users WHERE id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>

<h1 class="text-2xl font-bold text-white mb-6">Profile</h1>

<?php if ($message): ?>
<div class="p-4 mb-4 text-sm rounded-lg <?php echo $message_type == 'success' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'; ?>">
    <?php echo $message; ?>
</div>
<?php endif; ?>

<div class="bg-gray-800 p-6 rounded-lg shadow-lg mb-8">
    <div class="flex items-center space-x-4 mb-6">
        <div class="w-16 h-16 bg-cyan-500 rounded-full flex items-center justify-center text-3xl font-bold">
            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
        </div>
        <div>
            <h2 class="text-xl font-bold"><?php echo htmlspecialchars($user['username']); ?></h2>
            <p class="text-sm text-gray-400"><?php echo htmlspecialchars($user['email']); ?></p>
        </div>
    </div>
    <div class="text-sm text-gray-400">
        <p><i class="fas fa-calendar-alt fa-fw mr-2"></i>Joined: <?php echo date('d M, Y', strtotime($user['created_at'])); ?></p>
    </div>
</div>

<div class="bg-gray-800 p-4 rounded-lg shadow-lg mb-8">
    <a href="refer.php" class="flex justify-between items-center text-white">
        <div>
            <i class="fas fa-users fa-fw mr-3 text-cyan-400"></i>
            <span class="font-semibold">Refer & Earn</span>
        </div>
        <i class="fas fa-chevron-right text-gray-500"></i>
    </a>
</div>

<h2 class="text-xl font-bold text-white mb-4">Change Password</h2>
<div class="bg-gray-800 p-6 rounded-lg shadow-lg">
    <form action="profile.php" method="POST">
        <div class="mb-4">
            <label class="block text-gray-300 mb-2">Current Password</label>
            <input type="password" name="current_password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
        </div>
        <div class="mb-4">
            <label class="block text-gray-300 mb-2">New Password</label>
            <input type="password" name="new_password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
        </div>
        <div class="mb-6">
            <label class="block text-gray-300 mb-2">Confirm New Password</label>
            <input type="password" name="confirm_password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
        </div>
        <button type="submit" name="change_password" class="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 rounded-lg transition">Update Password</button>
    </form>
</div>

<div class="text-center mt-8">
    <a href="logout.php" class="text-red-400 hover:text-red-300 transition-colors">
        <i class="fas fa-sign-out-alt mr-2"></i>Logout
    </a>
</div>

<?php require_once 'common/bottom.php'; ?>
