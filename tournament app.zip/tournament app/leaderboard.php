<?php
require_once 'common/header.php';
require_login();

// Fetch top 100 users by total winnings
$sql = "SELECT username, total_winnings FROM users ORDER BY total_winnings DESC, username ASC LIMIT 100";
$result = $mysqli->query($sql);
?>

<h1 class="text-2xl font-bold text-white mb-6">🏆 Leaderboard</h1>
<p class="text-sm text-gray-400 mb-6">Top players ranked by total tournament winnings.</p>

<div class="space-y-3">
    <?php if ($result && $result->num_rows > 0): ?>
        <?php $rank = 1; ?>
        <?php while($user = $result->fetch_assoc()): ?>
            <?php
            $rank_color = "bg-gray-700";
            $rank_icon = "<span class='font-bold text-gray-400 w-6 text-center'>{$rank}</span>";
            if ($rank == 1) { $rank_color = "bg-amber-500/20"; $rank_icon = "<i class='fas fa-trophy text-amber-400 w-6 text-center'></i>"; }
            elseif ($rank == 2) { $rank_color = "bg-slate-500/20"; $rank_icon = "<i class='fas fa-medal text-slate-400 w-6 text-center'></i>"; }
            elseif ($rank == 3) { $rank_color = "bg-orange-600/20"; $rank_icon = "<i class='fas fa-medal text-orange-500 w-6 text-center'></i>"; }
            ?>
            <div class="flex items-center bg-gray-800 p-4 rounded-lg shadow-lg <?php echo $rank_color; ?>">
                <div class="text-lg mr-4"><?php echo $rank_icon; ?></div>
                <div class="flex-1">
                    <p class="font-bold text-white"><?php echo htmlspecialchars($user['username']); ?></p>
                </div>
                <div class="text-right">
                    <p class="font-bold text-cyan-400 text-lg">₹<?php echo number_format($user['total_winnings'], 2); ?></p>
                    <p class="text-xs text-gray-500">Winnings</p>
                </div>
            </div>
            <?php $rank++; ?>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="bg-gray-800 text-center p-8 rounded-lg">
            <i class="fas fa-ghost text-4xl text-gray-600 mb-4"></i>
            <p class="text-gray-400">No players on the leaderboard yet. Compete to be the first!</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'common/bottom.php'; ?>
