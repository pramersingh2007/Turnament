<?php
require_once 'common/config.php';

if (isset($_SESSION["user_id"])) {
    header("location: index.php");
    exit;
}

$active_tab = isset($_POST['form_type']) ? $_POST['form_type'] : 'login';
$login_error = $register_error = $register_success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if ($_POST['form_type'] === 'login') {
        $active_tab = 'login';
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        if (empty($username) || empty($password)) {
            $login_error = "Please enter both username and password.";
        } else {
            $sql = "SELECT id, username, password_hash FROM users WHERE username = ?";
            if ($stmt = $mysqli->prepare($sql)) {
                $stmt->bind_param("s", $param_username);
                $param_username = $username;
                if ($stmt->execute()) {
                    $stmt->store_result();
                    if ($stmt->num_rows == 1) {
                        $stmt->bind_result($id, $username, $hashed_password);
                        if ($stmt->fetch()) {
                            if (password_verify($password, $hashed_password)) {
                                $_SESSION["user_id"] = $id;
                                $_SESSION["username"] = $username;
                                header("location: index.php");
                                exit;
                            } else { $login_error = "Invalid password."; }
                        }
                    } else { $login_error = "No account found with that username."; }
                } else { $login_error = "Oops! Something went wrong."; }
                $stmt->close();
            }
        }
    }
    
    if ($_POST['form_type'] === 'register') {
        $active_tab = 'register';
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $confirm_password = trim($_POST['confirm_password']);
        $referrer_code = trim($_POST['referrer_code']);

        if (empty($username) || empty($email) || empty($password)) $register_error = "Please fill all fields.";
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $register_error = "Invalid email format.";
        elseif (strlen($password) < 6) $register_error = "Password must have at least 6 characters.";
        elseif ($password != $confirm_password) $register_error = "Passwords do not match.";
        
        if(empty($register_error)) {
            $sql_check = "SELECT id FROM users WHERE username = ? OR email = ?";
            if ($stmt_check = $mysqli->prepare($sql_check)) {
                $stmt_check->bind_param("ss", $username, $email);
                $stmt_check->execute();
                $stmt_check->store_result();
                if ($stmt_check->num_rows > 0) { $register_error = "Username or email already taken."; }
                $stmt_check->close();
            }
        }

        if (empty($register_error)) {
            $mysqli->begin_transaction();
            try {
                $referrer_id = null;
                if (!empty($referrer_code)) {
                    $stmt_ref = $mysqli->prepare("SELECT id FROM users WHERE referral_code = ?");
                    $stmt_ref->bind_param("s", $referrer_code);
                    $stmt_ref->execute();
                    $result_ref = $stmt_ref->get_result();
                    if ($user_ref = $result_ref->fetch_assoc()) { $referrer_id = $user_ref['id']; }
                    $stmt_ref->close();
                }

                do {
                    $new_referral_code = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 8);
                    $stmt_code_check = $mysqli->prepare("SELECT id FROM users WHERE referral_code = ?");
                    $stmt_code_check->bind_param("s", $new_referral_code);
                    $stmt_code_check->execute();
                    $stmt_code_check->store_result();
                    $code_exists = $stmt_code_check->num_rows > 0;
                    $stmt_code_check->close();
                } while ($code_exists);

                $sql_insert = "INSERT INTO users (username, email, password_hash, referral_code, referred_by_id) VALUES (?, ?, ?, ?, ?)";
                $stmt_insert = $mysqli->prepare($sql_insert);
                $param_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt_insert->bind_param("ssssi", $username, $email, $param_password, $new_referral_code, $referrer_id);
                $stmt_insert->execute();
                $stmt_insert->close();

                if ($referrer_id) {
                    $stmt_reward = $mysqli->prepare("UPDATE users SET wallet_balance = wallet_balance + 1 WHERE id = ?");
                    $stmt_reward->bind_param("i", $referrer_id);
                    $stmt_reward->execute();
                    $stmt_reward->close();
                }

                $mysqli->commit();
                $register_success = "Registration successful! Please login.";
                $active_tab = 'login';

            } catch (mysqli_sql_exception $exception) {
                $mysqli->rollback();
                $register_error = "An error occurred during registration. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Login - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style> body { -webkit-user-select: none; -ms-user-select: none; user-select: none; } </style>
</head>
<body class="bg-gray-900 text-white font-sans flex items-center justify-center min-h-screen">
    <div class="bg-gray-800 p-8 rounded-lg shadow-lg w-full max-w-sm">
        <h1 class="text-3xl font-bold text-center text-cyan-400 mb-6"><?php echo APP_NAME; ?></h1>
        <div class="flex border-b border-gray-700 mb-6">
            <button id="login-tab-btn" class="flex-1 py-2 text-center font-semibold transition-colors duration-300 <?php echo $active_tab == 'login' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-gray-400'; ?>" onclick="showTab('login')">Login</button>
            <button id="register-tab-btn" class="flex-1 py-2 text-center font-semibold transition-colors duration-300 <?php echo $active_tab == 'register' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-gray-400'; ?>" onclick="showTab('register')">Sign Up</button>
        </div>

        <div id="login-tab" style="<?php echo $active_tab == 'login' ? '' : 'display: none;'; ?>">
            <form action="login.php" method="POST">
                <input type="hidden" name="form_type" value="login">
                <?php if ($login_error): ?><p class="bg-red-500/20 text-red-300 p-3 rounded-lg mb-4 text-sm"><?php echo $login_error; ?></p><?php endif; ?>
                <?php if ($register_success): ?><p class="bg-green-500/20 text-green-300 p-3 rounded-lg mb-4 text-sm"><?php echo $register_success; ?></p><?php endif; ?>
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">Username</label>
                    <input type="text" name="username" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
                </div>
                <div class="mb-6">
                    <label class="block text-gray-300 mb-2">Password</label>
                    <input type="password" name="password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
                </div>
                <button type="submit" class="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 rounded-lg transition">Login</button>
            </form>
        </div>

        <div id="register-tab" style="<?php echo $active_tab == 'register' ? '' : 'display: none;'; ?>">
             <form action="login.php" method="POST">
                <input type="hidden" name="form_type" value="register">
                <?php if ($register_error): ?><p class="bg-red-500/20 text-red-300 p-3 rounded-lg mb-4 text-sm"><?php echo $register_error; ?></p><?php endif; ?>
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">Username</label>
                    <input type="text" name="username" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">Email</label>
                    <input type="email" name="email" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
                </div>
                 <div class="mb-4">
                    <label class="block text-gray-300 mb-2">Password</label>
                    <input type="password" name="password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">Confirm Password</label>
                    <input type="password" name="confirm_password" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500" required>
                </div>
                <div class="mb-6">
                    <label class="block text-gray-300 mb-2">Referral Code (Optional)</label>
                    <input type="text" name="referrer_code" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500">
                </div>
                <button type="submit" class="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 rounded-lg transition">Create Account</button>
            </form>
        </div>
    </div>
    
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
        function showTab(tabName) {
            document.getElementById('login-tab').style.display = 'none';
            document.getElementById('register-tab').style.display = 'none';
            document.getElementById(tabName + '-tab').style.display = 'block';
            document.getElementById('login-tab-btn').classList.remove('text-cyan-400', 'border-cyan-400');
            document.getElementById('register-tab-btn').classList.remove('text-cyan-400', 'border-cyan-400');
            document.getElementById(tabName + '-tab-btn').classList.add('text-cyan-400', 'border-cyan-400');
        }
    </script>
</body>
</html>
