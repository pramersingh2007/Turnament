<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo '<body style="font-family: monospace; background-color: #111; color: #eee;">';
echo '<h1>Environment Check</h1>';

// 1. Check current directory
$cwd = getcwd();
echo "<b>1. Current Working Directory:</b><br>" . $cwd . "<br><br>";

// 2. Check if 'common' directory exists
$common_dir = 'common';
echo "<b>2. Checking for 'common' directory...</b><br>";
if (file_exists($common_dir) && is_dir($common_dir)) {
    echo '<span style="color: #22c55e;">SUCCESS:</span> \'common\' directory found.<br><br>';
    
    // 3. Check if 'common' directory is writable
    echo "<b>3. Checking if 'common' directory is writable...</b><br>";
    if (is_writable($common_dir)) {
        echo '<span style="color: #22c55e;">SUCCESS:</span> \'common\' directory IS WRITABLE.<br><br>';
        echo '<h2>Installation should work now!</h2>';
    } else {
        echo '<span style="color: #ef4444;">ERROR:</span> \'common\' directory IS NOT WRITABLE.<br>';
        echo 'Please set the permission of the common folder to 777.<br><br>';
    }
} else {
    echo '<span style="color: #ef4444;">ERROR:</span> \'common\' directory NOT FOUND at this path.<br><br>';
}

echo '</body>';
?>
